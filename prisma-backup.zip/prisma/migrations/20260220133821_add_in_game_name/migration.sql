-- AlterTable
ALTER TABLE "users" ADD COLUMN     "in_game_name" TEXT;
